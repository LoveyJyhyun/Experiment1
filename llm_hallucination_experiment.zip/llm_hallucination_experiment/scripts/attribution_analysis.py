# TODO: Implement calculation of HR, PS, MV and generate plots
